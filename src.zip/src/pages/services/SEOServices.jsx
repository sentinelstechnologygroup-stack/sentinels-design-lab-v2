"use client";
import React from "react";
import { Search, Link2, Settings, MapPin, ShoppingBag, BarChart3 } from "lucide-react";
import FullServicePage from "../../components/shared/FullServicePage";

export default function SEOServices() {
  return (
    <FullServicePage
      badge="SEO Services — Ranking & Search Engine Dominance"
      headline="Data-Driven SEO Company"
      highlight="Powering Your Digital Growth"
      subheadline="SEO Marketing Experts Offering Ranking and Search Engine Dominance"
      description="Maximize visibility with proven SEO services and strategies with optimized rankings, increased organic traffic, and lasting online impact. Our certified specialists have helped brands achieve 300%+ traffic growth even in competitive markets."
      startingPrice="$299.99/mo"
      image="https://media.base44.com/images/public/69c84c79cf14625ad4e75595/dac7a80b3_generated_d3ba5320.png"
      stats={[
        { value: "250+", label: "SEO Campaigns" },
        { value: "150+", label: "Specialists" },
        { value: "10+", label: "Years Experience" },
        { value: "99%", label: "Client Retention" },
        { value: "300%+", label: "Avg Traffic Growth" },
        { value: "100%", label: "White-Hat Methods" },
      ]}
      aboutTitle="SEO Marketing Services That Deliver"
      aboutHighlight="Real Business Growth"
      aboutBody="At Sentinels Design Lab, our SEO marketing company delivers more than rankings — we engineer revenue growth. Our certified SEO marketing experts combine technical mastery with content strategy to drive qualified traffic that converts. Our data-backed approach has helped clients achieve 300%+ organic traffic growth, even in competitive markets."
      aboutBullets={[
        "Analytics-first approach combining data with creative execution",
        "Precision strategies reaching high-intent audiences at every stage",
        "Certified SEO specialists driving measurable, impactful results",
        "Tested frameworks from the best SEO agency in your vertical",
      ]}
      differentiators={[
        { title: "Technical Excellence", desc: "Full site audits covering 83+ technical, content, and competitive metrics." },
        { title: "Content That Ranks", desc: "Keyword-driven content strategy built around search intent and conversion." },
        { title: "Authority Building", desc: "White-hat link building from industry-specific, high-DA publications." },
        { title: "Full Transparency", desc: "Custom Google Data Studio dashboards with real-time ranking reports." },
      ]}
      servicesSubtitle="SEO Solutions"
      servicesTitle="SEO Marketing Services That Deliver Sustainable Growth"
      services={[
        { icon: Search, title: "On-Page SEO", description: "We optimize every visible element — content structures, meta tags, internal linking systems, and keyword placement — all aligned with search intent." },
        { icon: Link2, title: "Off-Page SEO", description: "Build authority through PR outreach, guest blogging, and strategic partnerships. High-quality, industry-specific placements that boost domain trust." },
        { icon: Settings, title: "Technical SEO", description: "We audit and optimize site speed, mobile responsiveness, indexability, and security. Eliminating crawl errors and implementing structured data." },
        { icon: MapPin, title: "Local SEO", description: "Dominate 'near me' searches with Google Business Profile optimization, local citations, geo-targeted content, and review management strategies." },
        { icon: ShoppingBag, title: "E-commerce SEO", description: "Turn product pages into revenue generators with optimized category structures, product schema, and unique descriptions that rank and convert." },
        { icon: BarChart3, title: "SEO Audits & Analytics", description: "Data-driven diagnostics combining 83+ technical, content, and competitive metrics in actionable reports with custom dashboards." },
      ]}
      portfolioSubtitle="Our Work"
      portfolioTitle="We Are Data-Powered SEO Machines"
      portfolioTabs={[
        { label: "On-Page SEO", icon: Search, description: "Boost your website's visibility on search engines and drive organic traffic with our expert on-page optimization techniques." },
        { label: "Off-Page SEO", icon: Link2, description: "Build lasting authority with strategic link acquisition from high-DA publications in your industry vertical." },
        { label: "Technical SEO", icon: Settings, description: "Fix crawlability, site speed, Core Web Vitals, and structured data — the foundation of top rankings." },
        { label: "Local SEO", icon: MapPin, description: "Dominate local search results and Google Maps to capture high-intent customers near you." },
        { label: "E-commerce SEO", icon: ShoppingBag, description: "Transform your product and category pages into organic traffic and revenue generators." },
      ]}
      processSubtitle="Our Process"
      processTitle="How We Deliver SEO Results"
      processSteps={[
        { title: "Full Site Audit", desc: "Comprehensive analysis of technical, content, and competitive gaps across 83+ metrics." },
        { title: "Strategy Development", desc: "Custom keyword strategy, content roadmap, and link building plan tailored to your goals." },
        { title: "On & Off-Page Execution", desc: "We implement optimizations, publish content, and acquire authoritative backlinks." },
        { title: "Monthly Reporting", desc: "Real-time dashboards, ranking reports, and strategy refinement every 30 days." },
      ]}
      pricingSubtitle="Pricing"
      pricingTitle="SEO Packages That Deliver Results"
      pricingPackages={[
        {
          name: "Starter SEO",
          originalPrice: "600.00",
          price: "299.99",
          features: ["On-Page SEO Audit", "Keyword Research (20 Keywords)", "Meta Tags Optimization", "Google Analytics Setup", "Monthly Ranking Report", "3-Month Commitment"],
        },
        {
          name: "Growth SEO",
          originalPrice: "1,200.00",
          price: "599.99",
          featured: true,
          features: ["Complete SEO Audit", "Keyword Research (50 Keywords)", "On-Page & Off-Page SEO", "Content Strategy & Creation", "Link Building (5/mo)", "Local SEO Setup", "Monthly Strategy Call", "6-Month Commitment"],
        },
        {
          name: "Authority SEO",
          originalPrice: "2,400.00",
          price: "1,199.99",
          features: ["Advanced Technical SEO", "Unlimited Keywords", "Content Creation (8 posts/mo)", "Premium Link Building (15/mo)", "Competitor Analysis", "Custom Analytics Dashboard", "Dedicated SEO Manager", "12-Month Commitment"],
        },
        {
          name: "Enterprise SEO",
          originalPrice: "4,800.00",
          price: "2,399.99",
          features: ["Multi-Site / National SEO", "Full Content Team", "PR & Digital Outreach", "Daily Rank Tracking", "Google News Optimization", "Conversion Rate Optimization", "Weekly Strategy Calls", "Custom SLA"],
        },
      ]}
      testimonialsSubtitle="Client Reviews"
      testimonialsTitle="They Believed in Us — You Will Too!"
      testimonials={[
        { name: "Anika Sharma", role: "Operations Director, HealthFirst Clinics", text: "We went from page 4 on Google to #1 for our primary keywords in under 5 months. The SDL SEO team is methodical, transparent, and genuinely invested in our growth." },
        { name: "Rachel Osei", role: "Founder, Bloom Education", text: "Our organic traffic has grown 220% since launch. The content strategy is brilliant and the technical work was immaculate. I've already referred three colleagues to SDL." },
        { name: "Daniel Okafor", role: "Ecommerce Manager, LuxGoods Co.", text: "SDL's SEO team helped our product pages rank for ultra-competitive keywords within 6 months. We saw a 65% increase in organic revenue in year one." },
      ]}
      trustBadges={["Google 4.9★", "Clutch 5.0★", "UpCity 4.8★", "300%+ Avg Traffic Growth", "White-Hat Only", "50% Off — Limited Time"]}
      ctaTitle="Ready to Dominate Search Rankings?"
      ctaDescription="Let our SEO experts create a custom strategy that drives real, measurable traffic and revenue."
    />
  );
}